package com.jcpdev.board;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Boot6BoardApplication {

	public static void main(String[] args) {
		SpringApplication.run(Boot6BoardApplication.class, args);
	}

}
